<?php
namespace Civi\CCase\Exception;

class MultipleActivityException extends \CRM_Core_Exception {

}